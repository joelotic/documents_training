package com.eazybytes.microservicesez;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicesezApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicesezApplication.class, args);
	}

}
